# Firefox Random Bookmark

A little add-on I created for personal use because at the time, I didn't find any other random bookmark add-ons at the time that had the features I wanted.

https://addons.mozilla.org/en-US/firefox/addon/random-bookmark-addon/
